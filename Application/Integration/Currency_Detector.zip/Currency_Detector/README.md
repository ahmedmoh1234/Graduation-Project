# Indian paper currency detection using ```opencv3``` and ```python3```

To run do
```python3 detect.py```

To set a different image modify the ```testing_image``` in detect.py

The failed parts are in try.py

UE14CS348 course - mini project  
Digital Image Processing  


## TODO:
### 	Figure out four point transform
###	Figure out testing data warping
### 	Use webcam as input
### 	Figure out how to use contours
### 		Currently detects inner rect -> detect outermost rectangle
### 	Try using video stream from android phone